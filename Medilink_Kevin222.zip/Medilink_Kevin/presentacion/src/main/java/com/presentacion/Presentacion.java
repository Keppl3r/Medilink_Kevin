/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.presentacion;

/**
 *
 * @author keppler
 */
public class Presentacion {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
