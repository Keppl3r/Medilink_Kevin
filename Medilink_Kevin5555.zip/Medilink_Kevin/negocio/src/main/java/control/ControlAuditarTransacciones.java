/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import dtos.DetalleTransaccionDTO;
import dtos.FiltrosBusquedaDTO;
import dtos.PagoDTO;
import dtos.TransaccionDTO;
import entidades.Auditoria;
import entidades.Transaccion;
import excepciones.NegocioException;
import excepciones.PersistenciaException;
import interfaces.ITransaccionDAO;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Control del subsistema mapeo, validación y delegación al DAO.
 *
 * @author keppler
 */
public class ControlAuditarTransacciones {

    private final ITransaccionDAO transaccionDAO;

    public ControlAuditarTransacciones(ITransaccionDAO transaccionDAO) {
        this.transaccionDAO = transaccionDAO;
    }

    public Integer contarPendientes() throws NegocioException {
        try {
            return transaccionDAO.contarPendientes();
        } catch (PersistenciaException e) {
            throw new NegocioException("Error al contar pendientes: " + e.getMessage(), e);
        }
    }

    public List<TransaccionDTO> buscarPorPeriodo(FiltrosBusquedaDTO filtros) throws NegocioException {
        validarRangoFechas(filtros.getInicio(), filtros.getFin());
        try {
            List<Transaccion> transacciones = transaccionDAO.buscarPorRango(
                    filtros.getInicio(), filtros.getFin());
            return mapearListaADTO(transacciones);
        } catch (PersistenciaException e) {
            throw new NegocioException("Error al buscar por periodo: " + e.getMessage(), e);
        }
    }

    public List<TransaccionDTO> buscarPorPaciente(FiltrosBusquedaDTO filtros) throws NegocioException {
        if (filtros.getNombrePaciente() == null || filtros.getNombrePaciente().isBlank()) {
            throw new NegocioException("El nombre del paciente es requerido");
        }
        try {
            List<Transaccion> transacciones = transaccionDAO.buscarPorPaciente(
                    filtros.getNombrePaciente());
            return mapearListaADTO(transacciones);
        } catch (PersistenciaException e) {
            throw new NegocioException("Error al buscar por paciente: " + e.getMessage(), e);
        }
    }

    public DetalleTransaccionDTO obtenerDetalle(String id) throws NegocioException {
        Transaccion transaccion = buscarTransaccion(id);
        return mapearDetalleADTO(transaccion);
    }

    public void auditarTransaccion(String id) throws NegocioException {
        Transaccion transaccion = buscarTransaccion(id);
        validarConsistencia(transaccion);
        try {
            Auditoria auditoria = new Auditoria(
                    null,
                    LocalDateTime.now(),
                    "Auditada",
                    1,
                    "Administrador"
            );
            transaccionDAO.agregarAuditoria(id, auditoria);
        } catch (PersistenciaException e) {
            throw new NegocioException("Error al auditar la transacción: " + e.getMessage(), e);
        }
    }

    public void marcarPendiente(String id) throws NegocioException {
        buscarTransaccion(id);
        try {
            transaccionDAO.actualizarEstado(id, "Pendiente");
        } catch (PersistenciaException e) {
            throw new NegocioException("Error al marcar pendiente: " + e.getMessage(), e);
        }
    }

    public PagoDTO obtenerPago(String idTransaccion) throws NegocioException {
        Transaccion transaccion = buscarTransaccion(idTransaccion);
        return mapearPagoADTO(transaccion);
    }

    //validaciones
    private void validarRangoFechas(LocalDateTime inicio, LocalDateTime fin) throws NegocioException {
        if (inicio == null || fin == null) {
            throw new NegocioException("Las fechas de inicio y fin son requeridas");
        }
        if (inicio.isAfter(fin)) {
            throw new NegocioException("La fecha de inicio no puede ser posterior a la fecha fin");
        }
    }

    private void validarConsistencia(Transaccion transaccion) throws NegocioException {
        if (transaccion.getMontoRecibido() == null || transaccion.getMontoEsperado() == null) {
            throw new NegocioException("Los montos no pueden ser nulos");
        }
        if (!transaccion.getMontoRecibido().equals(transaccion.getMontoEsperado())) {
            throw new NegocioException("Inconsistencia: monto recibido ("
                    + transaccion.getMontoRecibido() + ") no coincide con monto esperado ("
                    + transaccion.getMontoEsperado() + ")");
        }
        if (!"Exitoso".equals(transaccion.getMensajeEstado())) {
            throw new NegocioException("El pago de Stripe no fue exitoso: " + transaccion.getMensajeEstado());
        }
    }

    //mapeo 
    private Transaccion buscarTransaccion(String id) throws NegocioException {
        if (id == null || id.isBlank()) {
            throw new NegocioException("El ID de transacción es requerido");
        }
        try {
            Transaccion transaccion = transaccionDAO.buscarPorId(id);
            if (transaccion == null) {
                throw new NegocioException("No se encontró la transacción con ID: " + id);
            }
            return transaccion;
        } catch (PersistenciaException e) {
            throw new NegocioException("Error al buscar transacción: " + e.getMessage(), e);
        }
    }

    private TransaccionDTO mapearADTO(Transaccion t) {
        TransaccionDTO dto = new TransaccionDTO();
        dto.setId(t.getId());
        dto.setFecha(t.getFecha());
        dto.setMontoRecibido(t.getMontoRecibido());
        dto.setEstado(t.getEstado());
        dto.setNombrePaciente(t.getNombrePaciente());
        dto.setNombreMedico(t.getNombreMedico());
        return dto;
    }

    private List<TransaccionDTO> mapearListaADTO(List<Transaccion> transacciones) {
        List<TransaccionDTO> lista = new ArrayList<>();
        for (Transaccion t : transacciones) {
            lista.add(mapearADTO(t));
        }
        return lista;
    }

    private DetalleTransaccionDTO mapearDetalleADTO(Transaccion t) {
        DetalleTransaccionDTO dto = new DetalleTransaccionDTO();
        dto.setId(t.getId());
        dto.setFecha(t.getFecha());
        dto.setEstado(t.getEstado());
        dto.setNombrePaciente(t.getNombrePaciente());
        dto.setNombreMedico(t.getNombreMedico());
        dto.setTipoConsulta(t.getTipoConsulta());
        dto.setMontoEsperado(t.getMontoEsperado());
        dto.setMontoRecibido(t.getMontoRecibido());
        dto.setReferenciaStripe(t.getReferenciaStripe());
        dto.setMensajeEstado(t.getMensajeEstado());
        return dto;
    }

    private PagoDTO mapearPagoADTO(Transaccion t) {
        PagoDTO dto = new PagoDTO();
        dto.setReferenciaStripe(t.getReferenciaStripe());
        dto.setMontoRecibido(t.getMontoRecibido());
        dto.setMensajeEstado(t.getMensajeEstado());
        dto.setIdTransaccion(t.getId());
        return dto;
    }
}
